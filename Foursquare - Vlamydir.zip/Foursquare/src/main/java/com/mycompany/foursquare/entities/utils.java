package com.mycompany.foursquare.entities;

public interface utils {
    String URL_ROOT = "https://foursquare.webcindario.com/";
    //String URL_ROOT = "http://localhost/Foursquare/";
    //String URL_ROOT = "http://localhost/veggsy/";
    //String URL_ROOT = "https://veggsy.webcindario.com/";
}
